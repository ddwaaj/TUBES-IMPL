package com.rekap.demo;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.sql.*;

public class Admin {

    @FXML
    private TextField Findo;

    @FXML
    private TextField Finggris;

    @FXML
    private TextField Fipa;

    @FXML
    private TextField Fmtk;

    @FXML
    private TextField Fname;

    @FXML
    private TextField Fnis;

    @FXML
    private TableColumn<?, ?> NIS;
    @FXML
    private TableColumn<?, ?> Nama;

    @FXML
    private TableColumn<?, ?> Bahasa_Indonesia;

    @FXML
    private TableColumn<?, ?> Bahasa_Inggris;

    @FXML
    private TableColumn<?, ?> Ilmu_Pengetahuan_Alam;

    @FXML
    private TableColumn<?, ?> Matematika;

    @FXML
    private TableView<ObservableList<String>> tableView;


    @FXML
    void clear(ActionEvent event) {
        // Clear text fields
        Fnis.clear();
        Fname.clear();
        Findo.clear();
        Finggris.clear();
        Fipa.clear();
        Fmtk.clear();

    }

    @FXML
    void delete(ActionEvent event) {
        try {
            // Mendapatkan data yang dipilih dari tabel
            ObservableList<ObservableList<String>> selectedData = tableView.getSelectionModel().getSelectedItems();

            if (!selectedData.isEmpty()) {
                // Mendapatkan nilai NIS dari data yang dipilih (karena NIS adalah primary key)
                String selectedNIS = selectedData.get(0).get(0);

                try (Connection connection = DatabaseConnection.getConnection();
                     PreparedStatement statement = connection.prepareStatement("DELETE FROM siswa WHERE NIS = ?")) {
                    // Setel nilai parameter NIS
                    statement.setString(1, selectedNIS);

                    // Jalankan pernyataan
                    int rowsAffected = statement.executeUpdate();

                    if (rowsAffected > 0) {
                        // Menampilkan Alert jika penghapusan berhasil
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Sukses");
                        alert.setHeaderText(null);
                        alert.setContentText("Data berhasil dihapus!");
                        alert.showAndWait();

                        // Refresh tabel setelah penghapusan
                        refreshTable();
                    }
                }
            } else {
                // Menampilkan Alert jika tidak ada data yang dipilih
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Peringatan");
                alert.setHeaderText(null);
                alert.setContentText("Pilih data yang ingin dihapus!");
                alert.showAndWait();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @FXML
    void edit(ActionEvent event) {
        // Mendapatkan baris yang dipilih dari tabel
        ObservableList<String> selectedRow = tableView.getSelectionModel().getSelectedItem();

        // Memeriksa apakah ada baris yang dipilih
        if (selectedRow != null) {
            // Menempatkan data dari baris yang dipilih ke dalam TextField
            Fnis.setText(selectedRow.get(0));
            Fname.setText(selectedRow.get(1));
            Findo.setText(selectedRow.get(2));
            Finggris.setText(selectedRow.get(3));
            Fipa.setText(selectedRow.get(4));
            Fmtk.setText(selectedRow.get(5));

            // Menonaktifkan pengeditan kolom NIS
            Fnis.setDisable(true);
        } else {
            // Menampilkan Alert jika tidak ada baris yang dipilih
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Peringatan");
            alert.setHeaderText(null);
            alert.setContentText("Pilih baris yang akan diedit!");
            alert.showAndWait();
        }
    }




    @FXML
    void input(ActionEvent event) {
        // Memeriksa apakah data yang dimasukkan sudah ada dalam tabel (berdasarkan NIS)
        if (isDataValid()) {
            boolean isUpdate = isDataExists(Fnis.getText());

            try (Connection connection = DatabaseConnection.getConnection()) {
                if (isUpdate) {
                    // Jika NIS sudah ada, lakukan operasi pembaruan (UPDATE)
                    try (PreparedStatement updateStatement = connection.prepareStatement(
                            "UPDATE siswa SET Nama=?, Bahasa_Indonesia=?, Bahasa_Inggris=?, Ilmu_Pengetahuan_Alam=?, Matematika=? WHERE NIS=?")) {
                        updateStatement.setString(1, Fname.getText());
                        updateStatement.setString(2, Findo.getText());
                        updateStatement.setString(3, Finggris.getText());
                        updateStatement.setString(4, Fipa.getText());
                        updateStatement.setString(5, Fmtk.getText());
                        updateStatement.setString(6, Fnis.getText());

                        updateStatement.executeUpdate();
                    }
                } else {
                    // Jika NIS belum ada, lakukan operasi penyisipan baru (INSERT)
                    try (PreparedStatement insertStatement = connection.prepareStatement(
                            "INSERT INTO siswa (NIS, Nama, Bahasa_Indonesia, Bahasa_Inggris, Ilmu_Pengetahuan_Alam, Matematika) VALUES (?, ?, ?, ?, ?, ?)")) {
                        insertStatement.setString(1, Fnis.getText());
                        insertStatement.setString(2, Fname.getText());
                        insertStatement.setString(3, Findo.getText());
                        insertStatement.setString(4, Finggris.getText());
                        insertStatement.setString(5, Fipa.getText());
                        insertStatement.setString(6, Fmtk.getText());

                        insertStatement.executeUpdate();
                    }
                }

                // Perbarui tabel setelah penyisipan atau pembaruan
                // Panggil suatu metode untuk memperbarui data tabel
                refreshTable();

                // Menampilkan Alert jika penyisipan atau pembaruan berhasil
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Sukses");
                alert.setHeaderText(null);
                alert.setContentText(isUpdate ? "Data berhasil diperbarui!" : "Data berhasil disisipkan!");
                alert.showAndWait();

                // Mengaktifkan kembali pengeditan kolom NIS setelah operasi selesai
                Fnis.setDisable(false);

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            // Menampilkan Alert jika ada data yang kosong
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Semua kolom harus diisi!");
            alert.showAndWait();
        }
    }

    // Metode untuk memeriksa apakah data sudah ada dalam tabel berdasarkan NIS
    private boolean isDataExists(String nis) {
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM siswa WHERE NIS=?")) {
            statement.setString(1, nis);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next(); // Mengembalikan true jika data sudah ada, false jika belum
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @FXML
    void refresh(ActionEvent event) {
        // Memanggil metode refreshTable untuk meng-update tabel
        refreshTable();
    }

    // Metode untuk memeriksa apakah ada data yang kosong
    private boolean isDataValid() {
        return !Fnis.getText().isEmpty() && !Fname.getText().isEmpty() && !Findo.getText().isEmpty() && !Finggris.getText().isEmpty() && !Fipa.getText().isEmpty() && !Fmtk.getText().isEmpty();
    }

    // Metode untuk meng-update tabel
    private void loadDataFromDatabase() {
        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM siswa")) {

            ObservableList<ObservableList<String>> data = FXCollections.observableArrayList();

            // Menambahkan kolom dinamis sesuai dengan metadata kolom
            for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
                final int j = i - 1;
                TableColumn<ObservableList<String>, String> col = new TableColumn<>(resultSet.getMetaData().getColumnName(i));
                col.setCellValueFactory(param -> new SimpleStringProperty(param.getValue().get(j)));
                tableView.getColumns().addAll(col);
            }


            // Memuat data dari ResultSet ke dalam ObservableList
            while (resultSet.next()) {
                ObservableList<String> row = FXCollections.observableArrayList();
                for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
                    row.add(resultSet.getString(i));
                }
                data.add(row);
            }

            // Menetapkan data ke dalam TableView
            tableView.setItems(data);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void refreshTable() {
        // Membersihkan kolom sebelum menambahkan kolom baru
        tableView.getColumns().clear();

        // Memanggil metode untuk memuat data dari database
        loadDataFromDatabase();
    }
}

