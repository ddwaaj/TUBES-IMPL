package com.rekap.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;

public class Admin {

    @FXML
    private TableColumn<?, ?> NIS;

    @FXML
    private TableColumn<?, ?> Nama;

    @FXML
    private TableColumn<?, ?> bindonesia;

    @FXML
    private TableColumn<?, ?> binggris;

    @FXML
    private TableColumn<?, ?> mtk;

    @FXML
    void clear(ActionEvent event) {

    }

    @FXML
    void delete(ActionEvent event) {

    }

    @FXML
    void edit(ActionEvent event) {

    }

    @FXML
    void input(ActionEvent event) {

    }

}
